FMS Finance Management System - Android Offline 1.0

Mradi huu ni Android app rahisi inayofungua mfumo wa FMS uliowekwa ndani ya app (WebView). Haufanyi mawasiliano ya mtandao; miamala huhifadhiwa kwenye local storage ya app.

Kujenga APK:
- Tumia Android Gradle Plugin 8.6.1 na Gradle 8.7 au toleo linalooana.
- JDK 17
- Android SDK platform 35 na build-tools 35.0.0
- Amri: gradle assembleDebug
- APK: app/build/outputs/apk/debug/app-debug.apk

Tahadhari: Hili ni toleo la mwanzo/prototype. Si mfumo wa benki wala si ushauri wa kuweka taarifa nyeti bila encryption na backup salama.
